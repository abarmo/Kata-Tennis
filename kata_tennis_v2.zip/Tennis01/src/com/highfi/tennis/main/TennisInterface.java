package com.highfi.tennis.main;

import java.util.List;

/**
 * Interface to be implemented by Services
 * 
 * @since Saturday 08 July 2017 AT 03h00 PM.
 * @author Mohamed ABARCHIDS
 * 
 */
public interface TennisInterface {
	
	 static StringBuilder currentScrors = new StringBuilder("(0-0)");
	 static StringBuilder oldScors      = new StringBuilder();
	 static StringBuilder gameStatus    = new StringBuilder("0-0");
	 static StringBuilder matchStatus   = new StringBuilder("In progress");
	
	 void updateScores(List<Player> listPlayers, int winnerPosition, int looserPosition) ;
	
	 void initScores(List<Player> listPlayers) ;
	
	 void updateMatchState(List<Player> listPlayers, int winnerPosition, int looserPosition) ;
	
	 void verifyAdvantages(List<Player> listPlayers, int winnerPosition, int looserPosition) ;

	 void updateAdvantages(Player winner, Player looser);

	 void determineWinnerAndLooser(List<Player> listPlayers, String in) ;
	
	 int getWinnerPosition(List<Player> listPlayers) ;
	
	 int getLooserPosition(List<Player> listPlayers) ;

	 StringBuilder updateDisplay(List<Player> listPlayers);

	 String displayCurrentScores();

	 String displayOldScores();
 
	 Boolean isGameOver(List<Player> listPlayers);

}