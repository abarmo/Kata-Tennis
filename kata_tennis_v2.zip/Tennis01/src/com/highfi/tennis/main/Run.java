package com.highfi.tennis.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
public class Run {
	
	/**
	 * 
	 * Class main of KATA TENNIS
	 * Version : V1.2
	 * 
	 * @since Saturday 08 July 2017 AT 03h00 PM.
	 * @author Mohamed ABARCHID
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		
		Player player1 = new Player(1); // We decided to fix Player 1 is in the first  Position.
		Player player2 = new Player(2); // We decided to fix Player 2 is in the second Position.
		player1.setName("Player1");     // Player1 is the name of the first  Player.
		player2.setName("Player2");     // Player2 is the name of the second Player.
		
		List<Player> listPlayers = new ArrayList<>();// LIST used to fix the order of the tow players.
		listPlayers.add(player1);
		listPlayers.add(player2);
		
		
		String in; // Response of the user
		BufferedReader br = null;	
		Boolean isNotGameOver = Boolean.TRUE;
		/**
		 * FROM HERE A TENNIS MATCHE IS LAUNCHED
		 */
		TennisService tennisPart = new TennisService();

		try {
			br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("------------START----------");
			while (isNotGameOver) {
				System.out.println("Player  1 : "+player1.getName());
				System.out.println("Player  2 : "+player2.getName());
				System.out.println("Score : "+tennisPart.displayOldScores() + tennisPart.displayCurrentScores());
				System.out.println("Current game status : " + TennisService.gameStatus.toString());
				System.out.println("Match Status : " + TennisService.matchStatus);
	        	if(tennisPart.isGameOver(listPlayers)) {
	        		return;
	        	}
                System.out.print("Enter 'a' if Player 1 scrors or any other key if Player 2 scrors : ");
                in = br.readLine();
                tennisPart.determineWinnerAndLooser(listPlayers, in);
	        	int winnerPosition = tennisPart.getWinnerPosition(listPlayers);
	        	int looserPosition = tennisPart.getLooserPosition(listPlayers);

	        	tennisPart.updateMatchState(listPlayers, winnerPosition, looserPosition);
				System.out.println("\n\n\n\n\n");
			}
		} catch (Exception e) {
			throw new Exception(e);// TO DO : Implement TechnicalExceptions Later
		}	 
	}
}