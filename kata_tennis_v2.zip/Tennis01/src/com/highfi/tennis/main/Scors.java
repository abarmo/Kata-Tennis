package com.highfi.tennis.main;

/**
 * Enum Representing SCORES OF TENNIS
 * 
 * @since Saturday 08 July 2017 AT 03h00 PM.
 * @author Mohamed ABARCHID
 */
public enum Scors {

	    SCORE_AD(41),
        SCORE_00(0),
        SCORE_15(15),
        SCORE_30(30),
        SCORE_40(40);

        public final int value;

        Scors(final int newValue) {
            value = newValue;
        }

        public int getValue() { 
             return value; 
        }
        
        static Scors fromValue(int value) {
            for (Scors my: Scors.values()) {
                if (my.value == value) {
                    return my;
                }
            }
            return null;
        }
}