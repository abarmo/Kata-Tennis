package com.highfi.tennis.main;


/**
 * Object Class Representing a Player with all his necessary parameters.
 * 
 * @since Saturday 08 July 2017 AT 03h00 PM.
 * @author Mohamed ABARCHIDS
 *
 */
public class Player {
	
	private String  name;
	private int     scores;          // 1 score = 10 points or 30, 40
	private int     games;           // 1 games = 40 scores + 1 point
	private int     sets;            // 1 set = 6 games : 1,2,3,4,5,6 or 7
	private boolean advantage;       // true , or false, if already true so a set is wan
	private boolean matcheWinner;    // if a player have more than 3 sets, he wins the match
	private boolean wins;    // if a player have more than 3 sets, he wins the match
	private int     order;    // if a player have more than 3 sets, he wins the match

	public Player() {
		// EMPTY CONSTRUCTOR
	}
	
	public Player(int order) {
		this.order     = order;
	}
	
	public Player(String name, int scores, int games, int sets, boolean advantage, int match, boolean matcheWinner, int order) {
		this.name         = name;
		this.scores       = scores;
		this.games        = games;
		this.sets         = sets;
		this.advantage    = advantage;
		this.matcheWinner = matcheWinner;
		this.order        = order;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScores() {
		return scores;
	}

	public void setScores(int score) {
		this.scores = score;
	}

	public int getGames() {
		return games;
	}

	public void setGames(int games) {
		this.games = games;
	}

	public int getSets() {
		return sets;
	}

	public void setSets(int set) {
		this.sets = set;
	}

	public boolean hasAdvantage() {
		return advantage;
	}

	public void setAdvantage(boolean advantage) {
		this.advantage = advantage;
	}

	public boolean isMatcheWinner() {
		return matcheWinner;
	}

	public void setMatcheWinner(boolean matcheWinner) {
		this.matcheWinner = matcheWinner;
	}

	public boolean isWins() {
		return wins;
	}

	public void setWins(boolean wins) {
		this.wins = wins;
	}

	public int getOrder() {
		return order;
	}
}