package com.highfi.tennis.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.commons.lang3.StringUtils;
public class Run {

	public static void main(String[] args) {
		
		Player player1 = new Player();
		Player player2 = new Player();
		player1.setName("Player1");
		player2.setName("Player2");
		String in;
		
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("------------START----------");
			int score1 = 0;
			int score2 = 0;
			String matchStatus = "In progress";
			int advantage1 = 0;
			int advantage2 = 0;
	    	

			while (true) {
				System.out.println("Player  1 : "+player1.getName());
				System.out.println("Player  1 : "+player2.getName());
				System.out.println("Score : "+TennisUtil.displayScores());
				System.out.println("Current game status : "+player1.getScore()+" - "+player2.getScore());
				System.out.println("Match Status : "+matchStatus);
                System.out.print("Enter 'a' if Player 1 scrors or 'b' if Player 2 scrors : ");
                in = br.readLine();
                Games scoresPlayer1 = Games.fromValue(player1.getScore());
                Games scoresPlayer2 = Games.fromValue(player2.getScore());

	        	if(StringUtils.equals(in, "a")) {
	        		switch (scoresPlayer1) {
	        		  case GAME_0  : player1.setScore(Games.GAME_15.value); break;
	        		  case GAME_15 : player1.setScore(Games.GAME_30.value); break;
	        		  case GAME_30 : player1.setScore(Games.GAME_40.value); break;
	        		  case GAME_40 :
	        			  if(player1.getAdvantage()) {//le paler1 a deja un avantage
	        				       					         
	        			      TennisUtil.scores(player1, player2, false);  	        					  
			        		  break;
	        				  
	        			    
	        	         } else {
	        	        	 TennisUtil.scores(player1, player2, false);     
	        	         }
	        			 ;
	        	         break;
	        	         default: System.out.println("error no scores found");;
			          }
	        	}
	        	
				System.out.println("");
				System.out.println("");
				System.out.println("");
				System.out.println("");
				System.out.println("");

			}        
		} catch (Exception e) {
			e.printStackTrace();
		}	 
	}
}
