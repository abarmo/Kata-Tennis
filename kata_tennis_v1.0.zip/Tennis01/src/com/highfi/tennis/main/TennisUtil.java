package com.highfi.tennis.main;

import org.apache.commons.lang3.StringUtils;

public final class TennisUtil {

		
	static StringBuilder scrors = new StringBuilder();
	static StringBuilder scrorsold = new StringBuilder();
	static int[] intArray = new int[2];
	
	public  static void scores(Player p1, Player p2,  boolean init ){

    	  if((p1.getSets() + 1) > p2.getSets() + 2  && (p1.getSets() + 1) == 6) { // He win a set while last set are 6-4  or 7-5
				  p1.winGame(false);
			      display(p1,p2, false);
				  //init
				  display(p1,p2, true);
		  }  else { // he win a set while all sets are between : 0 and 5
			      p1.winGame(true);
			      display(p1,p2, true);

         } 
     }
	
	public  static void display(Player p1, Player p2, boolean init){
		  intArray[0] = p1.getSets();
		  intArray[1] = p2.getSets();	
		  scrors.setLength(0);
		  scrors.append("(");
		  scrors.append(StringUtils.join(intArray, '-'));			        					
		  scrors.append(")");  	
		  if(init){
			  p1.setScore(0);
			  p2.setScore(0);   
		  }
	}
	
	public static String displayScores (){
		return scrorsold.append(scrors.toString()).toString();
	}
}