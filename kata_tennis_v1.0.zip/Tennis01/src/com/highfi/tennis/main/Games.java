package com.highfi.tennis.main;

public enum Games {

        GAME_0(0),
        GAME_15(15),
        GAME_30(30),
        GAME_40(40);

        public final int value;

        Games(final int newValue) {
            value = newValue;
        }

        public int getValue() { 
             return value; 
        }
        
        static Games fromValue(int value) {
            for (Games my: Games.values()) {
                if (my.value == value) {
                    return my;
                }
            }
            return null;
        }
}
