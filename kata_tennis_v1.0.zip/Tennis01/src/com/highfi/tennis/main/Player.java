package com.highfi.tennis.main;

public class Player {
	
	private String name;
	private int score; // 10, 30, 40
	private int sets;  // 1,2,3,4,5,6 or 7
	private boolean advantage; //true , or false, if already true so , 	 	a set is wined
	private int match; // if a player have more than 7 set or 6 set, he win the match
	private boolean winner; // if a palyer have 2 match and win a match so he is the winner
	
	public Player() {
		// EMPTY CONSTRUCTOR
	}
	
	public Player(String name, int score, int set, boolean advantage, int match, boolean winner) {
		this.name = name;
		this.score = score;
		this.sets = set;
		this.advantage = advantage;
		this.match = match;
		this.winner = winner;
	}
	
	public void winGame(boolean noinit){
		  if(noinit){
			 this.sets = this.sets + 1;
		  }
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getSets() {
		return sets;
	}

	public void setSets(int set) {
		this.sets = set;
	}

	public boolean getAdvantage() {
		return advantage;
	}

	public void setAdvantage(boolean advantage) {
		this.advantage = advantage;
	}

	public int getMatch() {
		return match;
	}

	public void setMatch(int match) {
		this.match = match;
	}

	public boolean isWinner() {
		return winner;
	}

	public void setWinner(boolean winner) {
		this.winner = winner;
	}
}
